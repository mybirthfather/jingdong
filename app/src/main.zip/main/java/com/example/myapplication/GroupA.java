package com.example.myapplication;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

public class GroupA extends FrameLayout {
    private static final String TAG = "GroupA";

    public GroupA(Context context) {
        super(context);
    }

    public GroupA(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public GroupA(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.e(TAG, "dispatchTouchEvent: " + Utils.getMotionEvent(ev.getAction()));

        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        Log.e(TAG, "onInterceptTouchEvent: " + Utils.getMotionEvent(ev.getAction()));

        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        Log.e(TAG, "onTouchEvent: " + Utils.getMotionEvent(ev.getAction()));

        return super.onTouchEvent(ev);
    }
}
