package com.example.myapplication;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

public class MyView extends View {
    private static final String TAG = "MyView";

    public MyView(Context context) {
        this(context,null);
    }

    public MyView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs,0);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public MyView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
//        setZ(100);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
//        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
//        int wideSize = MeasureSpec.getSize(widthMeasureSpec);
//        Log.e(TAG, "onMeasure: widthMode="+widthMode+"wideSize="+wideSize);
//        String sMode = Integer.toBinaryString(widthMode);
//        String sSize = Integer.toBinaryString(wideSize);
//        Log.e(TAG, "binary: sMode="+sMode+"sSize="+sSize );
//        Log.e(TAG, "binary: widthMeasureSpec="+Integer.toBinaryString(widthMeasureSpec));
//        // mask 11后面30个0 取反 前面就是0 和widthMeasureSpec 与 去掉了widthMeasureSpec的模式位 后面的值位置不影响
//
////        1000 0000 0000 0000 0000 0000 0000 0000
        int mode = MeasureSpec.getMode(heightMeasureSpec);
        int size = MeasureSpec.getSize(heightMeasureSpec);
//
        Log.e(TAG, "heightMode="+Integer.toBinaryString(mode)+"heightsize="+size);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

    }
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.e(TAG, "dispatchTouchEvent: " + Utils.getMotionEvent(ev.getAction()));
        return super.dispatchTouchEvent(ev);
    }



//    @Override
//    public boolean onTouchEvent(MotionEvent ev) {
//        Log.e(TAG, "onTouchEvent: " + Utils.getMotionEvent(ev.getAction()));
//
//        return super.onTouchEvent(ev);
////        return true;
//    }


}
