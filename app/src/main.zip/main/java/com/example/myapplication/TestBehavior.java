package com.example.myapplication;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;

import java.util.ArrayList;
import java.util.List;

public class TestBehavior extends HeaderBehavior<View> {
    private static final String TAG = "TestBehavior";
    private int maxHeight = 0;//一开始的高度 最后要还原到这个高度的
    private int leftSpace = 0;
    private int rightSpace = 0;
    private int extraSpace = 0;
    private int topSpace=0;
    public TestBehavior() {
    }

    public TestBehavior(Context context, AttributeSet attrs) {

        super(context, attrs);
        leftSpace = Utils.dip2px(context, 56);
        rightSpace = Utils.dip2px(context, 100);
        extraSpace = Utils.dip2px(context, 12);
        topSpace=maxHeight/2;
    }

    //
    @Override
    public void onNestedScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View child, @NonNull View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, int type, @NonNull int[] consumed) {
//        ViewGroup.LayoutParams childLayoutParams = child.getLayoutParams();
        int childHeight = child.getHeight();
        View tv = child.findViewById(R.id.tv);
        RelativeLayout.LayoutParams tvLayoutParams = (RelativeLayout.LayoutParams) tv.getLayoutParams();
        ViewGroup.LayoutParams childLayoutParams = child.getLayoutParams();

        Log.e(TAG, "onNestedScroll: " + "dyConsumed=" + dyConsumed + "dyUnconsumed=" + dyUnconsumed + "dxUnconsumed=" + dxUnconsumed);
        if (dyUnconsumed < 0) {//rv滑动不动了 顶部改变
            if (childHeight < maxHeight) {
                childHeight -= dyUnconsumed;
                if (childHeight > maxHeight) {//否则会超出
//                    consumed[1] = childHeight - maxHeight + dyUnconsumed;
                    childHeight = maxHeight;
                }
                childLayoutParams.height = childHeight;
                consumed[1] = dyUnconsumed;


            }
            if (tvLayoutParams.leftMargin > extraSpace || tvLayoutParams.rightMargin > extraSpace) {
                tvLayoutParams.leftMargin += dyUnconsumed;
                tvLayoutParams.rightMargin += dyUnconsumed;

                if (tvLayoutParams.leftMargin < extraSpace) {
                    tvLayoutParams.leftMargin = extraSpace;
                }
                if (tvLayoutParams.rightMargin < extraSpace) {
                    tvLayoutParams.rightMargin = extraSpace;
                }

//                tv.setLayoutParams(tvLayoutParams);
            }
            if (!child.isLayoutRequested()){
                child.setLayoutParams(childLayoutParams);

            }

//            coordinatorLayout.postInvalidate();
//            child.setLayoutParams(childLayoutParams);

        }
        //如果
        super.onNestedScroll(coordinatorLayout, child, target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed, type, consumed);
    }

    //在onlayout的时候获取高度
    //这里返回true才能接受滚动事件
    @Override
    public boolean onStartNestedScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View child, @NonNull View directTargetChild, @NonNull View target, int axes, int type) {
        int childHeight = child.getHeight();

        float y = target.getY();
        Log.e(TAG, "onStartNestedScroll: " + "childHeight=" + childHeight + "y=" + y);
//        return super.onStartNestedScroll(coordinatorLayout, child, directTargetChild, target, axes, type);
        return true;
    }

    //这个方法是滚动刚被发起 还没背消费的dy滚动距离

    /**
     * 如果你想在rv滑动前先滑动就要自己消费这一段距离 并把消费过的返回去告诉父容器
     * 抖动可能是因为先上滑产生了正的值  马上又产生了-的值 又去nestScroll去了 都刷新View导致连续requsetlayout了？ 貌似不是这个问题
     *单纯设置 tv的margin值 不会产生抖动 抖动可能是因为大小不确定的问题 本来正值应该都去了 nestscroll了 但是 这里他妈的
     * @param coordinatorLayout
     * @param child
     * @param target
     * @param dx
     * @param dy
     * @param consumed          这个方法中的consumed才具有传递作用 如果直接consumed[1]=dy则后续的方法将没有值可以消费
     * @param type
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onNestedPreScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View child, @NonNull View target, int dx, int dy, @NonNull int[] consumed, int type) {
//        consumed 设置得是消耗过的
        View rl = child.findViewById(R.id.rl);
        View tv = child.findViewById(R.id.tv);
        RelativeLayout.LayoutParams tvLayoutParams = (RelativeLayout.LayoutParams) tv.getLayoutParams();
        int childHeight = child.getMeasuredHeight();
        Log.e(TAG, "onNestedPreScroll: " + "dy=" + dy);

        if (maxHeight == 0 && childHeight != 0) {
            maxHeight = childHeight;

        }
        ViewGroup.LayoutParams childLayoutParams = child.getLayoutParams();
        float y = target.getY();//因为rv向下移动多了 所以显示不全了 底部
        // 如果产生了负的 就会执行onNestscroll方法了
        //而且这里的 consumed[1] 不设置表示没消费 也会执行onNestedScroll方法就会一起滚动
        if (dy > 0) {//向上滑动
            child.offsetTopAndBottom(-dy);
                            consumed[1] = dy;

//            if (childHeight > rl.getHeight()) {
//                childHeight -= dy;
//                if (childHeight < rl.getHeight()) {
////                    consumed[1] = dy + childHeight - rl.getHeight();
//                    childHeight = rl.getHeight();
//                }
//                childLayoutParams.height = childHeight;
//                consumed[1] = dy;
//
//            }
//
//            if (tvLayoutParams.leftMargin < leftSpace) {
//                tvLayoutParams.leftMargin += dy;
//                tvLayoutParams.rightMargin += 2 * dy;
//
//                if (tvLayoutParams.leftMargin > leftSpace) {
//                    tvLayoutParams.leftMargin = leftSpace;
//                }
//                if (tvLayoutParams.rightMargin > rightSpace) {
//                    tvLayoutParams.rightMargin = rightSpace;
//                }
//            }
//            if (!child.isLayoutRequested()){
//                child.setLayoutParams(childLayoutParams);
//
//            }

        }
        //小雨0的时候 如果仍没滑倒顶假装消费了并且让他继续消费？变负的？方法不可行

    }

    @Override
    public boolean onRequestChildRectangleOnScreen(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View child, @NonNull Rect rectangle, boolean immediate) {
        return super.onRequestChildRectangleOnScreen(coordinatorLayout, child, rectangle, immediate);
    }

    @Override
    public boolean onNestedPreFling(@NonNull CoordinatorLayout coordinatorLayout, @NonNull View child, @NonNull View target, float velocityX, float velocityY) {

        Log.e(TAG, "onNestedPreFling: velocityY=" + velocityY);

        return super.onNestedPreFling(coordinatorLayout, child, target, velocityX, velocityY);
    }
}
