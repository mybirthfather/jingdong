package com.example.myapplication;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RecyclerViewBehavior extends CoordinatorLayout.Behavior<RecyclerView> {
    private static final String TAG = "RecyclerViewBehavior";
    private int totalHeight = 0;

    public RecyclerViewBehavior() {

    }

    public RecyclerViewBehavior(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean layoutDependsOn(CoordinatorLayout parent, RecyclerView child, View dependency) {
        float y = child.getY();
        int height = dependency.getHeight();
        return dependency instanceof RelativeLayout;
    }

    @Override
    public boolean onDependentViewChanged(CoordinatorLayout parent, RecyclerView child, View dependency) {
        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) child.getLayoutParams();
        //计算列表y坐标，最小为0
//        int top = child.getTop();
        View rl = dependency.findViewById(R.id.rl);//他是最终剩的高度
        if (rl.getHeight() != 0 && totalHeight == 0) {
            totalHeight = rl.getHeight();
        }
        offsetChildAsNeeded(child,dependency);
        return false;
    }

    @Override
    public boolean onRequestChildRectangleOnScreen(@NonNull CoordinatorLayout coordinatorLayout, @NonNull RecyclerView child, @NonNull Rect rectangle, boolean immediate) {
        Log.e(TAG, "onRequestChildRectangleOnScreen: " );
        return super.onRequestChildRectangleOnScreen(coordinatorLayout, child, rectangle, immediate);
    }

    private void offsetChildAsNeeded(@NonNull View child, @NonNull View dependency) {

        ViewCompat.offsetTopAndBottom(
                child,
                (dependency.getBottom() - child.getTop()));
    }

    @Nullable
    RelativeLayout findFirstDependency(@NonNull List<View> views) {
        for (int i = 0, z = views.size(); i < z; i++) {
            View view = views.get(i);
            if (view instanceof RelativeLayout) {
                return (RelativeLayout) view;
            }
        }
        return null;
    }

    final Rect tempRect1 = new Rect();
    final Rect tempRect2 = new Rect();

    private static int resolveGravity(int gravity) {
        return gravity == Gravity.NO_GRAVITY ? GravityCompat.START | Gravity.TOP : gravity;
    }

    @Override
    public boolean onLayoutChild(@NonNull CoordinatorLayout parent, @NonNull RecyclerView child, int layoutDirection) {
        final List<View> dependencies = parent.getDependencies(child);
        final View header = findFirstDependency(dependencies);
        if (header != null) {
            final CoordinatorLayout.LayoutParams lp =
                    (CoordinatorLayout.LayoutParams) child.getLayoutParams();
            final Rect available = tempRect1;
            available.set(
                    parent.getPaddingLeft() + lp.leftMargin,
                    header.getBottom() + lp.topMargin,
                    parent.getWidth() - parent.getPaddingRight() - lp.rightMargin,
                    parent.getHeight() + header.getBottom() - parent.getPaddingBottom() - lp.bottomMargin);
//            final WindowInsetsCompat parentInsets = parent.getLastWindowInsets();
//            if (parentInsets != null
//                    && ViewCompat.getFitsSystemWindows(parent)
//                    && !ViewCompat.getFitsSystemWindows(child)) {
//                // If we're set to handle insets but this child isn't, then it has been measured as
//                // if there are no insets. We need to lay it out to match horizontally.
//                // Top and bottom and already handled in the logic above
//                available.left += parentInsets.getSystemWindowInsetLeft();
//                available.right -= parentInsets.getSystemWindowInsetRight();
//            }

            final Rect out = tempRect2;
            GravityCompat.apply(
                    resolveGravity(lp.gravity),
                    child.getMeasuredWidth(),
                    child.getMeasuredHeight(),
                    available,
                    out,
                    layoutDirection);

            final int overlap = 0;

            child.layout(out.left, out.top - overlap, out.right, out.bottom - overlap);


            return true;
        } else {
            // If we don't have a dependency, let super handle it
            return super.onLayoutChild(parent, child, layoutDirection);
        }

    }

    /**
     * @param coordinatorLayout
     * @param child
     * @param directTargetChild
     * @param target
     * @param axes
     * @param type
     * @return
     */
    @Override
    public boolean onStartNestedScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull RecyclerView child, @NonNull View directTargetChild, @NonNull View target, int axes, int type) {
        float y = child.getY();
        int targetHeight = target.getHeight();

        return false;//这个竟然能影响rv是否显示下拉边界效果。。。。而且他不返回true 他的NestedScroll方法不会执行
    }


    /**
     * 自己作为发起
     */
    @Override
    public void onNestedScroll(@NonNull CoordinatorLayout coordinatorLayout, @NonNull RecyclerView child, @NonNull View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, int type, @NonNull int[] consumed) {
        Log.e(TAG, "onNestedScroll: "+ "dyUnconsumed="+dyUnconsumed+"consumed="+ Arrays.toString(consumed));
        super.onNestedScroll(coordinatorLayout, child, target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed, type, consumed);
    }

    //参考 appbarlayout 的 HeaderScrollingViewBehavior 的源码改的
    //重新测量rv的高度 因为 默认给他的是全屏幕的要减去header的高度

    /**
     *布局也要重新变 因为如果rv的高度仍是满屏幕的话 滑动距离会变小，所以底部的就滑不动了
     * 这部操作在onlayout里做 上面重写了
     * 可滚动控件的高度一定是有限的 因为计算滚动区域是内容高度减去控件高度的
     * offsettopbottom是移动的自己相对于父容器的位置 移动过后 getTop值会发生变化
     * 他移动的不是内容 源码里边就有对top值的修改 但是评议后可能超出屏幕外 导致部分内容看不到 所以这种方式不可取
     * 除非一起滚动貌似可以这样搞
     *
     * @return
     */
    @Override
    public boolean onMeasureChild(@NonNull CoordinatorLayout parent, @NonNull RecyclerView child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed) {
        Log.e(TAG, "onMeasureChild: ");
        final int childLpHeight = child.getLayoutParams().height;
        if (childLpHeight == ViewGroup.LayoutParams.MATCH_PARENT
                || childLpHeight == ViewGroup.LayoutParams.WRAP_CONTENT) {
            // If the menu's height is set to match_parent/wrap_content then measure it
            // with the maximum visible height
            final List<View> dependencies = parent.getDependencies(child);
            final View header = findFirstDependency(dependencies);
            if (header != null) {
                int availableHeight = View.MeasureSpec.getSize(parentHeightMeasureSpec);
                if (availableHeight > 0) {
                    if (ViewCompat.getFitsSystemWindows(header)) {
//                        final WindowInsetsCompat parentInsets = parent.getLastWindowInsets();
//                        if (parentInsets != null) {
//                            availableHeight += parentInsets.getSystemWindowInsetTop()
//                                    + parentInsets.getSystemWindowInsetBottom();
//                        }
                    }
                } else {
                    // If the measure spec doesn't specify a size, use the current height
                    availableHeight = parent.getHeight();
                }

                int height = availableHeight;
                int headerHeight = header.getMeasuredHeight();
                if (false) {
                    child.setTranslationY(-headerHeight);
                } else {
                    height -= headerHeight;
                }
                final int heightMeasureSpec =
                        View.MeasureSpec.makeMeasureSpec(
                                height,
                                childLpHeight == ViewGroup.LayoutParams.MATCH_PARENT
                                        ? View.MeasureSpec.EXACTLY
                                        : View.MeasureSpec.AT_MOST);

                // Now measure the scrolling view with the correct height
                parent.onMeasureChild(
                        child, parentWidthMeasureSpec, widthUsed, heightMeasureSpec, heightUsed);

                return true;
            }
        }
        return false;


    }
}
