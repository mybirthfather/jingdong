package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.appbar.AppBarLayout;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
//        AppBarLayout.ScrollingViewBehavior
//        AppBarLayout
//        ContentFrameLayout
//        MyScrollView ms = findViewById(R.id.ms);

        RecyclerView rv = findViewById(R.id.rv);
        AppBarLayout abl = findViewById(R.id.abl);

//        View ll = findViewById(R.id.tv);
//        int top = rv.getTop();
//        ll.setOnClickListener((v) -> {
//            Log.e(TAG, "before offset: top=" + top+"rv.getHeight()"+rv.getHeight());
////            rv.offsetTopAndBottom(200);
//            rv.setY(-500);//-的他就顶上去了
//
//            int topAfter = rv.getTop();
//            Log.e(TAG, "after offset: top=" + topAfter+"rv.getHeight()"+rv.getHeight());
//
//
//        });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        rv.setLayoutManager(linearLayoutManager);
        TestAdapter testAdapter = new TestAdapter();
        rv.setAdapter(testAdapter);
    }



}