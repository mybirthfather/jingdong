package com.example.myapplication;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.widget.OverScroller;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.NestedScrollingChild3;
import androidx.core.view.NestedScrollingChildHelper;
import androidx.core.view.ViewCompat;
import androidx.core.widget.EdgeEffectCompat;

import com.google.android.material.appbar.AppBarLayout;

import static androidx.customview.widget.ViewDragHelper.INVALID_POINTER;

public class MyTextView extends androidx.appcompat.widget.AppCompatTextView {
    private final int mTouchSlop;
    private VelocityTracker mVelocityTracker;
    private static final String TAG = "MyTextView";
    private final NestedScrollingChildHelper mChildHelper;
    private final int[] mScrollOffset = new int[2];
    private final int[] mScrollConsumed = new int[2];
    private int mNestedYOffset;
    private boolean mIsBeingDragged = false;
    private final Rect mTempRect = new Rect();
    private OverScroller mScroller;
    private int mLastScrollerY;
    private int mLastMotionY;
    private int mActivePointerId = INVALID_POINTER;

    public MyTextView(Context context) {
        this(context, null);
    }

    public MyTextView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MyTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mChildHelper = new NestedScrollingChildHelper(this);
        mScroller = new OverScroller(context);
        final ViewConfiguration configuration = ViewConfiguration.get(getContext());
        mTouchSlop = configuration.getScaledTouchSlop();

    }

    public static class Behavior extends CoordinatorLayout.Behavior<MyTextView>{

    }
}
